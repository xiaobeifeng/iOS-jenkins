/**
 * @description This is common js for intercept with Native Application using jsbridge
 * 
 * @version 2.0.2
 * 修改“webfetchParam”，“backBtnAction”，“getAccountInfoPWA”的逻辑遗漏，主要修改在某些情况下函数没有回调的问题
 *
 * @version 2.0.1
 * 修改webgetNativeStorage微信端调用方法
 * 修改chooseAccountPWA 发送广播id修改成NSSUserAccountChangedMessage，保持和手机端一致
 * 
 * @version  2.0.0
 */

/**
 * @description 弹出一个Toast
 * @ignore
 * msg： 显示内容
 * time:消失时间
 */
function webshowNativeToast(msg, time) {
    /*
     * adiv : 新生成div
     * aspan : 新生成div 子元素span
     * msg : 显示文字参数;
     * time : 时间参数，时间内消失，默认 1.5s;
     */
    if (document.getElementById("alertm")) {
        document.body.removeChild(document.getElementById("alertm"));
    }
    var adiv = document.createElement("div");
    adiv.setAttribute("id", "alertm");
    adiv.style.position = "fixed";
    adiv.style.bottom = "50px";
    adiv.style.left = "0";
    adiv.style.right = "0";
    adiv.style.textAlign = "center";
    adiv.style.zIndex = "99999";

    var aspan = document.createElement("span");
    adiv.appendChild(aspan);
    aspan.style.display = "inline-block";
    aspan.style.padding = "5px 45px";
    aspan.style.color = "#fff";
    aspan.style.fontSize = "14px";
    aspan.style.background = "rgba(33, 33, 33, .7)";
    aspan.style.borderRadius = "5px";

    aspan.innerText = msg;

    document.body.appendChild(adiv);

    if (time == null || time == "") {
        time = 1500;
    }
    setTimeout("document.body.removeChild(document.getElementById('alertm'))", time);
}


/**
 * @description 通过createNewWebPage打开一个新的page，如果用默认式样，则naviStyle可以不设置。其中naviStyle的naviBackTheme分为“LIGHT”，“GRAY”，“DARK”三种备选值。
 * @param {*} obj： {pageId:界面标识,url:地址,param:当前界面向新界面传的的参数,titleName：导航栏标题, naviStyle:{naviColor: 导航条颜色如#1B77FE, naviTitleColor:导航栏标题颜色如#1B77FE, naviBackTheme:返回键类型}}
 */
function webcreateNewWebPage(obj) {

    webSetCurPageId(obj);
    if (typeof obj.param == "string") {  //存储单个属性
        localStorage.setItem("webCreateNewPage", obj.param);
    } else if (typeof obj.param == "object") { //存储对象，以JSON格式存储
        localStorage.setItem("webCreateNewPage", JSON.stringify(obj.param));
    }
    location.href = obj.url;
}

/**
 * @description 获取从其他页面createNewWebPage到自己时其他页面传入的参数
 *  @ignore
 */
function webfetchParam() {

    var data = localStorage.getItem("webCreateNewPage");
//	localStorage.removeItem("webCreateNewPage");
    if (data != null && data != "") {
        if (data.indexOf("{") != -1 || data.indexOf("[") != -1) { //读取对象，以JSON格式读取
            J2C.onFetchParamSuccessed(JSON.parse(data));
        } else {   //读取单个对象
            J2C.onFetchParamSuccessed(data);
        }
    } else {
        J2C.onFetchParamSuccessed({});
    }

}

/**
 * @description http封装
 * @param url
 * @param type
 * @param isAsync
 * @param time
 * @param success
 * @param error
 */
function httpreq(url, type, data, headers, isAsync, time, success) {
    var request = new XMLHttpRequest();
    var timeout = false;
    var timer = setTimeout(function () {
        timeout = true;
        request.abort();
    }, time);
    request.open(type, url, isAsync);

    Object.getOwnPropertyNames(headers).forEach(function (key) {
        request.setRequestHeader(key, headers[key]);
    })

    request.onreadystatechange = function () {
        if (request.readyState !== 4) return;
        if (timeout) return;
        clearTimeout(timer);
        var headers = request.getAllResponseHeaders();

        var responseobj = {
            "status": request.status,
            "data": request.response,
            "headers": headers
        }
        success(responseobj);

    };

    request.send(['put', 'post'].indexOf(type.toLocaleLowerCase()) === -1 ? null : JSON.stringify(data));
}

function http_builder_url(url, data) {
    if (typeof(url) == 'undefined' || url == null || url == '') {
        return '';
    }
    if (typeof(data) == 'undefined' || data == null || typeof(data) != 'object') {
        return '';
    }
    url += (url.indexOf("?") != -1) ? "" : "?";
    for (var k in data) {
        url += ((url.indexOf("=") != -1) ? "&" : "") + k + "=" + encodeURI(data[k]);
        console.log(url);
    }
    return url;
}

/**
 * @description 调用申请使用net request (不要直接使用，请使用封装函数sendRequest)
 * @param {*} requestUrl: 端口之后的地址
 * @param {*} requestMethod： 请求方法
 * @param {*} requestQueries： 请求参数（适用于get请求，问号后的请求参数封成的对象）
 * @param {*} requestBody： 请求体
 * @param {*} callback： 回调函数，callback(statusObject, responseBody, responseHeaders);
 */
function webrequestNet(requestUrl, requestMethod, requestQueries, requestBody, requestHeaders, callback, type) {
    var url = http_builder_url(requestUrl, requestQueries);
    // alert(url);
    httpreq(url, requestMethod, requestBody, requestHeaders, true, 6000, function (response) {
        console.log('suc', response);
        var data = response.data;
        try {
            var tem = JSON.parse(data);
            data = tem;
        } catch (e) {
        }
        callback({"code": response.status}, data, response.headers); // 成功执行

    })

    // $http({
    //     method: requestMethod,
    //     url: requestUrl,
    //     params: requestQueries,
    //     data: requestBody,
    //     headers: requestHeaders
    // }).then(function succesCallback(response) {
    //         callback({"code": response.status}, response.data, response.headers); // 成功执行
    //     },
    //     function errorCallback(response) {
    //
    //         callback({"code": response.status}, response.data, response.headers);
    //     });
}


/**
 * @description  本地化存储函数,获取用户信息，通过key 获取需要的val,注意：key与val都是字符串
 * @ignore
 * {key:存储key,val:存储值}
 */
function websaveNativeStorage(key, val) {

    localStorage.setItem(key, val);
}



/**
 * @description  获取本地化存储
 *  @ignore
 *  {key:存储key,invokeCallback:回调}
 */
function webgetNativeStorage(skey,serialNum, invokeCallback) {
    //读取单个对象

    var obj = {
        val:localStorage.getItem(skey),
        serialNum:serialNum
    };
    if (obj == null || typeof obj == 'undefined') {
        obj = {};
    }
    J2C.onGetNativeStorageSuccessed(obj);

}



/**
 * @description  通过webSetCurPageId设置当前页面的pageID
 * @param {*} obj：{pageId:界面标识}
 */
function webSetCurPageId(obj) {
    if (localStorage.getItem("curPageList") == "" || localStorage.getItem("curPageList") == null) {
        var curPageList = [];
    } else {
        curPageList = JSON.parse(localStorage.getItem("curPageList"));
    }
    curPageList.push(obj);
    localStorage.setItem("curPageList", JSON.stringify(curPageList));

}

/**
 * @description  监听返回事件
 * @ignore
 * callback：回调函数
 * obj：
 * toPageId:回退到的指定page的Id，不能没有，可以等于一个空串，表示回退到上一个
 */
function backBtnAction(callback) {
    pushHistory();

    var newCallback = genNewCallback(callback);

    window.addEventListener("popstate", newCallback, false);

    function genNewCallback(callback) {
        return function (event) {
            callback(event);
            pushHistory();
        }
    }

    function pushHistory() {
        var state = {
            title: "title",
            url: "#"
        };
        window.history.pushState(state, "title", "#");
    }
}


/**
 * @description  回退到指定page
 * @ignore
 * obj：
 * toPageId:回退到的指定page的Id，不能没有，可以等于一个空串，表示回退到上一个
 */
function webBackToPage(obj) {
    var ishas = false;
    if (localStorage.getItem("curPageList") == "" || localStorage.getItem("curPageList") == null) {
        var curPageList = [];
    } else {
        curPageList = JSON.parse(localStorage.getItem("curPageList"));
        for (var i = 0; i < curPageList.length; i++) {
            if (obj.toPageId == curPageList[0].pageId) {  // 回到首页，清空堆栈
                localStorage.removeItem("curPageList");
                location.href = curPageList[0].url;
                ishas = true;
                break;
            } else if ((obj.toPageId == curPageList[i].pageId) && (obj.toPageId != curPageList[0].pageId)) {
                location.href = curPageList[i].url;
                ishas = true;
                break;
            }
            if (obj.toPageId == "" || obj.toPageId == null) {  // 没有pageid直接回上一页
                ishas = true;
                history.go(-1);
                break;
            }
        }
    }
    // 没有对应的pageId，表示回退到上一个
    if (!ishas) {
        history.go(-1);
    }
}


/**
 * @description   调取pdf模板，显示pdf
 * @ignore
 *  paramJsonObj : 显示pdf的入参
 *  browser : 浏览器类型
 *  pageId : 跳到pdf页面的页面id
 *  url : pdf模板页面路径
 *  param : 跳到pdf模板的入参
 */
function getViewPdf(paramJsonObj, browser) {
    console.log(browser)
    var obj = {};
    obj.pageId = "pdf";
    obj.url = global_config.ahrefUrl + "pdfView/pdf.html";
    if (browser == "PC") {
        paramJsonObj.url = paramJsonObj.url + paramJsonObj.weixin || "";
    } else if (browser == "WECHAT") {
        paramJsonObj.url = paramJsonObj.url + paramJsonObj.weixin || "";
    }
    obj.param = paramJsonObj;
    console.log(obj)
    J2C.createNewWebPage(obj);
}


/**
 * @description   注册接收广播的callback
 * @ignore
 * feature : 广播识别码
 * callback: function(obj){...}
 * obj:广播传递消息对象(json对象)
 */
function registerBroadcastPWA(feature, serialNum) {
    if (localStorage.getItem("curPageList") == "" || localStorage.getItem("curPageList") == null) {
        var curPageList = [];
        var vobj = {
            "pageId": "root",
            "url": window.location.href
        }
        webSetCurPageId(vobj);
    }
    curPageList = JSON.parse(localStorage.getItem("curPageList"));
    for (curpage in curPageList) {
        if (curPageList[curpage].url == window.location.href) {
            if (isEmpty(curPageList[curpage][feature])) {
                J2C.onBroadcastInvoked(serialNum, curPageList[curpage][feature]);
                break;
            }
            curPageList[curpage][feature] = feature;
            localStorage.setItem("curPageList", JSON.stringify(curPageList));
        }
    }
}


/**
 * @description   发送广播
 * @ignore
 * feature：广播识别码
 * obj：广播传递消息对象(json对象)
 *
 */
function sendBroadcastPWA(feature, obj) {
    curPageList = JSON.parse(localStorage.getItem("curPageList"));
    for (curpage in curPageList) {
        if (isEmpty(curPageList[curpage][feature])) {
            for (key in curPageList[curpage]) {
                console.log(key)
                if (key == feature) {
                    console.log("监听到了")
                    curPageList[curpage][feature] = obj;
                    localStorage.setItem("curPageList", JSON.stringify(curPageList));
                }
            }

        }
    }
}

/**   --------------------- 账户系统 --------------------------------------
 *  @description 一下函数为账户系统函数
 * 注意说明 accountId为账户的唯一标识，userName为用户名，accountId与userName可以相同
 */


/**
 * @description  获取账户系统登录过的历史记录
 *  @param serialNum: 随机数
 *  获取格式为：callback(obj), obj对象格式 [{"userName":"accountId"}]
 */
function getLogInHistoryPWA(serialNum) {
    var logHisLists = [];
    var accountIdList = isEmpty(localStorage.getItem("accountIdList")) ? JSON.parse(localStorage.getItem("accountIdList")) : [];
    if (accountIdList.length > 0) {  // 有账户系统
        for (i in accountIdList) {
            if (accountIdList[i] != "PublicAccount") {  // 账户历史记录不会有PublicAccount
                var l = {"userName": accountIdList[i]};
                logHisLists.push(l);
                // alert(logHisLists)

            }
        }
    }
    var loginH = {"serialNum": serialNum, "obj": JSON.stringify(logHisLists)};
    // alert(loginH)
    J2C.onGetLogInHistory(loginH);
}

// function getLogInHistoryPWA(serialNum){
//     var logHisLists = [];
//     var accountIdList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];
//     if(accountIdList.length >0){  // 有账户系统
//         for(i in accountIdList){
//             if(accountIdList[i] != "PublicAccount"){  // 账户历史记录不会有PublicAccount
//                 var l = {"userName":accountIdList[i]};
//                 logHisLists.push(JSON.stringify(l));
//                 alert(logHisLists)
//             }
//         }
//     }
//     var loginH = {"serialNum":serialNum,"obj":logHisLists};
//     alert(loginH)
//     J2C.onGetLogInHistory(loginH);
// }


/**
 * @description  获取账户系统当前accountId，当accountId为“PublicAccount”时，表示没有登录状态
 *  @param serialNum: 随机数
 *  获取格式为：callback(accountId)
 */
function getLogInAccountIdPWA(serialNum) {

    var loginAc = [];
    var loginHistoryList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];
    if (loginHistoryList.length > 0) {  // 有账户系统
        for (i in loginHistoryList) {

            loginAc.push(loginHistoryList[i].loginTrue ? true : false);  // 所有账户系统登录状态集合

            if (loginHistoryList[i].loginTrue) {
                var obj = {
                    "accountId": loginHistoryList[i].accountId,
                    "serialNum": serialNum
                }
                J2C.ongetLogInAccountId(obj);
            }
        }
        if (loginAc.indexOf(true) < 0) {  // 没有登录状态
            var obj = {
                "accountId": "PublicAccount",
                "serialNum": serialNum
            }
            J2C.ongetLogInAccountId(obj);
        }
    } else {  // 没有账户系统，没有登录状态
        var obj = {
            "accountId": "PublicAccount",
            "serialNum": serialNum
        }
        J2C.ongetLogInAccountId(obj);
    }
}

/**
 * @description  将accouId账号设置成登录状态,调用次方法后会发送账户变更广播通知,可绑定UserAccountChangedMessage广播接听
 *  @param accountId: 账号的唯一标识
 * 注意：如果getLogInHistory 获取的列表中没有要改变的accountId，必须先调用saveAccountInfo或者saveUserInfo
 */
function chooseAccountPWA(accountId) {
    var loginHistoryList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];

    if (loginHistoryList.length > 0) {
        for (i in loginHistoryList) {
            loginHistoryList[i].loginTrue = false;
            if (loginHistoryList[i].accountId == accountId) {
                loginHistoryList[i].loginTrue = true;
                var trueItem = loginHistoryList[i];
                var trueItem1 = loginHistoryList[i];
                spliceList(trueItem, loginHistoryList);
                loginHistoryList.splice(0, 0, trueItem1);  // 标准为true，为当前登录状态，在列表前面
            } else if (accountId == "PublicAccount") {
                var obj = {
                    "accountId": "PublicAccount",
                    "loginTrue": true
                }
                // loginHistoryList.push(obj);
            }
        }
    }

    localStorage.setItem("loginHistoryList", JSON.stringify(loginHistoryList));
    sendBroadcastPWA("NSSUserAccountChangedMessage", {"param": accountId});
    console.log(loginHistoryList)
}

/**
 * @description  退出登录状态，accountId变为“PublicAccount”
 *  @ignore
 */
function logInOutPWA() {

    var loginHistoryList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];
    console.log(loginHistoryList)
    chooseAccountPWA("PublicAccount");
    J2C.getLogInAccountId();
}

/**
 * @description  存储token，refreshToken，userName，accountId
 *  @ignore
 *  注意：这四个都是必传字段
 */
function saveAccountInfoPWA(accountId, token, refreshToken, userName) {
    var info = {
        "accountId": accountId,
        "token": token,
        "refreshToken": refreshToken,
        "userName": userName
    }
    saveUserInfoPWA(accountId, "accountInfo", JSON.stringify(info));

}

/**
 * @description  存储用户信息，以key-val方式存储
 *  @ignore
 *
 */
function saveUserInfoPWA(accountId, key, val) {

    var accountIdList = isEmpty(localStorage.getItem("accountIdList")) ? JSON.parse(localStorage.getItem("accountIdList")) : [];
    var loginHistoryList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];
    if (loginHistoryList.length > 0 && accountIdList.indexOf(accountId) >= 0) {
        for (i in loginHistoryList) {
            if (loginHistoryList[i].accountId == accountId) {
                loginHistoryList[i][key] = val;
                break;
            }
        }
    } else {
        var obj = {"accountId": accountId,}
        obj[key] = val;
        loginHistoryList.push(obj);
        accountIdList.push(accountId);
    }
    localStorage.setItem("loginHistoryList", JSON.stringify(loginHistoryList));
    localStorage.setItem("accountIdList", JSON.stringify(accountIdList));
}

/**
 * @description    获取账户信息，token，refreshToken，userName，accountId
 *  @ignore
 * 获取格式为：callback(obj), obj对象格式 {"token":"","refreshToken":"","userName":"","accountId":""}
 */
function getAccountInfoPWA(accountId, serialNum) {
    var loginHistoryList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];
    if (loginHistoryList.length > 0) {
        for (i in loginHistoryList) {
            if (loginHistoryList[i].accountId == accountId) {
                var obj = {
                    "accountId": accountId,
                    "userName": accountId,
                    "serialNum": serialNum,
                    "token": JSON.parse(loginHistoryList[i].accountInfo).token,
                    "refreshToken": JSON.parse(loginHistoryList[i].accountInfo).refreshToken
                };
                J2C.onGetAccountInfo(obj);
                return;
            }
        }
    }

    J2C.onGetAccountInfo({});
}


/**
 * @description    获取用户信息，通过key 获取需要的val
 *  @ignore
 * 获取格式为：callback(val), val字符串
 */
function getUserInfoPWA(accountId, key, serialNum) {
    var loginHistoryList = isEmpty(localStorage.getItem("loginHistoryList")) ? JSON.parse(localStorage.getItem("loginHistoryList")) : [];
    if (loginHistoryList.length > 0) {
        for (i in loginHistoryList) {
            if (loginHistoryList[i].accountId == accountId) {
                var obj = {"serialNum": serialNum, "val": loginHistoryList[i][key]};
                J2C.ongetUserInfo(obj);
//			} else if(accountId == "PublicAccount"){
//				var obj = {"serialNum":serialNum,"val":""};
//				J2C.ongetUserInfo(obj);
            }
        }
    } else {
        var obj = {"serialNum": serialNum, "val": ""};
        J2C.ongetUserInfo(obj);
    }
}
