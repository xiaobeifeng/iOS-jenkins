/**
 * This is common js for intercept with Native Application
 * using jsbridge
 *
 * Version 1.1.2
 *
 *
 */
(function() {

	// 判断window对象中是否存在"J2C"，如果不存在，注册命名空间 'J2C' 到window对象上
	if(undefined == window['J2C']) {
		window['J2C'] = {}
	}

	// ---------- JS -> Native ---------------------

	// ---------- call Android Application from js---------------------

	/**
	 * net request 返回后的回调
	 */
	getToken4NanNingBack = function(tokenObject) {
		//	 	locals.set("token", tokenObject);
		window.localStorage.setItem("token", tokenObject)

	};

	/**
	 * 调用申请使用getToken4Naning
	 */
	function requestGetToken4Nanning(callback) {
		getToken4NanNingBack = callback;
		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.requestGetToken4Nanning.postMessage(1);

		} else if(window.WebViewJ2CJavascriptBridge) {
			// 		var token = locals.get("token", "");
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.requestGetToken4Nanning', {
					'param': "测试"
				},
				function(responseData) {}
			);

		} else if(window.WeixinJSBridge) {
			getUserInfowechat();
		} else if(window.AlipayJSBridge) {
			getUserInfowechat();
		} else {
			getUserInfowechat();
		}

	}

	//---------- call js from Android Application ---------------------

	/**
	 * Native中invoke了GetToken4NanNing后回调JS的方法
	 */
	function onGetTokenSuccessed4NanNing(tokenObject) {
		getToken4NanNingBack(tokenObject);
	}

	/**
	 * requestISLogin request 返回后的回调
	 */
	isLoginback = function(statusObject) {};

	/**
	 * requestISLogin request 判断用户是否登陆
	 */
	function requestISLogin(callback) {
		isLoginback = callback;

		if(window.iosdkqgqc) {
			window.webkit.requestISLogin();

		} else if(window.WebViewJ2CJavascriptBridge) {
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.requestISLogin', {},

				function(responseData) {}
			);

		} else {
			throw new Error('J2C env init error');
		}
	}

	/**
	 * Native中invoke了requestISLogin后回调JS的方法
	 */
	function requestISLoginSuccessed(statusObject) {
		isLoginback(statusObject);
	}

	/**
	 * requestCertification request 返回后的回调
	 */
	isPensionCertificationback = function(statusObject) {};

	/**
	 * requestPensionCertification request 养老资格认证--直接返回成功失败结果
	 */
	function requestPensionCertification(idNumber, name, callback) {

		isPensionCertificationback = callback;

		if(window.iosdkqgqc) {
			// alert("1111")
			window.webkit.messageHandlers.requestPensionCertification.postMessage({
				'idNumber': idNumber,
				'name': name
			});

		} else if(window.WebViewJ2CJavascriptBridge) {
			// alert("222")
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.requestPensionCertification', {
					'idNumber': idNumber,
					'name': name
				},

				function(responseData) {}
			);

		} else {
			throw new Error('J2C env init error');
		}
	}

	/**
	 * Native中invoke了requestCertification后回调JS的方法
	 */
	function requestPensionCertificationSuccessed(statusObject) {
		isPensionCertificationback(statusObject);
	}

	/**
	 * requestCertification request 返回后的回调
	 */
	isInjuryCertificationback = function(statusObject) {};

	/**
	 * requestCertification request 工伤资格认认证--直接返回成功失败结果
	 */
	function requestInjuryCertification(idNumber, name, callback) {
		isInjuryCertificationback = callback;

		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.requestInjuryCertification.postMessage({
				'idNumber': idNumber,
				'name': name
			});
		} else if(window.WebViewJ2CJavascriptBridge) {
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.requestInjuryCertification', {
					'idNumber': idNumber,
					'name': name
				},

				function(responseData) {}
			);

		} else {
			throw new Error('J2C env init error');
		}
	}

	/**
	 * Native中invoke了requestCertification后回调JS的方法
	 */
	function requestInjuryCertificationSuccessed(statusObject) {
		isInjuryCertificationback(statusObject);
	}
	
	/**
	 * survivalback request 返回后的回调
	 */
	var survivalback = function(statusObject) {};

	/**
	 * requestSurvival request 生存认证  --返回code值，返回给后台，后台自己判断code值是否成功还是失败或者错误信息
	 */
	function requestSurvival(idNumber, name, callback) {

		survivalback = callback;

		if(window.iosdkqgqc) {
			// alert("1111")
			window.webkit.messageHandlers.requestSurvival.postMessage({
				'idNumber': idNumber,
				'name': name
			});

		} else if(window.WebViewJ2CJavascriptBridge) {
			// alert("222")
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.requestSurvival', {
					'idNumber': idNumber,
					'name': name
				},

				function(responseData) {}
			);

		} else {
			throw new Error('J2C env init error');
		}
	}

	/**
	 * Native中invoke了requestSurvival后回调JS的方法
	 */
	function onrequestSurvivalSuccessed(statusObject) {
		survivalback(statusObject);
	}

	//----------- others -----------------------------------------------

	/**
	 * pdf下载及展示(仅支持get方式)
	 * @param {*} paramJsonObj
	 * url：pdf下载地址
	 * titleName：展示pdf页面标题
	 * requestHeaders: 请求头
	 * requestQueries：请求参数
	 */
	function viewPdf(paramJsonObj) {
		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.viewPdf.postMessage({
				'body': paramJsonObj
			});

		} else if(window.WebViewJ2CJavascriptBridge) {

			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.viewPdf', paramJsonObj,
				function(responseData) {}
			);

		} else if(window.WeixinJSBridge) {
			getViewPdf(paramJsonObj, "WECHAT");
		} else if(window.AlipayJSBridge) {
			getViewPdf(paramJsonObj, "ALIPAY");
		} else {
			getViewPdf(paramJsonObj, "PC");
		}
	}

	var scanFaceCallback = new function(obj) {};

	/**
	 * 活体识别
	 * obj:调用参数
	 * obj至少包含如下：
	 * {"type": 使用的第三方（yiwei）},其他如有其他字段需要传递，在obj中进行字段扩展
	 * invokeCallback:回调，参数为一个jsonobj，参数格式如下
	 * { "result": "success"/"fail"其中success表示活体识别成功，fail表示失败, "type":"使用的第三方（yiwei）,"face":人脸base64String}, 其他如有其他字段需要传递，在对象中进行字段扩展
	 */
	function scanFace(obj, invokeCallback) {
		if(invokeCallback != null)
			scanFaceCallback = invokeCallback;

		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.scanFace.postMessage({
				'body': obj
			});
		} else if(window.WebViewJ2CJavascriptBridge) {
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.scanFace', obj,
				function(responseData) {}
			);
		} else if(window.WeixinJSBridge) {

		} else if(window.AlipayJSBridge) {

		} else {

		}
	}

	/**
	 * 获取活体的回调
	 */
	function onScanFaceSuccessed(callbackparam) {
		scanFaceCallback(callbackparam);
	};

	/*
	 * 定义调用二维码扫描获取数据的callback
	 * obj既createNewPage中的param
	 */
	var startQRCodeCallback = new function(obj) {};
	/*
	 * 调用二维码扫描获取数据
	 */
	function startQRCode(callback) {
		startQRCodeCallback = callback;
		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.startQRCode.postMessage(1);
		} else if(window.WebViewJ2CJavascriptBridge) {
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.startQRCode', {},
				function(responseData) {}
			);
		} else {
			throw new Error('J2C env init error');
		}
	}

	/*
	 * 调用二维码扫描获取数据的Native回调
	 * obj内容：
	 * qrResult:二维码扫描结果
	 */
	function onstartQRCodeSuccessed(obj) {
		startQRCodeCallback(obj);
	}

   
    var startXunfeiYuYinCallback = function(obj) {};

    /**
     * 开始语音识别时
     * 需要回调 : 1、开始倒计时flag2、过程回调（error和音量）
     * obj：需要入参,包含如下：
     * 录音时长（speechTimeOut）（ms单位）（默认60000ms） 
     * 语言种类（ language）（zh_cn（中文）、zh_tw（中文台湾）、en_us（英文）） 默认 zh_cn（中文）
     * 语言区域（accent）（mandarin (普通话) henanese（河南话）sichuanese（四川话）cantonese（粤语） 默认mandarin (普通话))
	 *
     */
    function startXunfeiYuYin(obj,callback) {
        if(callback != null)
			startXunfeiYuYinCallback = callback;
        if(window.iosdkqgqc) {
            window.webkit.messageHandlers.startXunfeiYuYin.postMessage({'body':obj});
        } else if(window.WebViewJ2CJavascriptBridge) {
            window.WebViewJ2CJavascriptBridge.callHandler(
                'Native.startXunfeiYuYin', obj,

                function(responseData) {}
            );

        } else {
            throw new Error('J2C env init error');
        }
    }

    /**
     * Native中invoke了startXunfeiYuYin后回调JS的方法
     */
    function onstartXunfeiYuYined(obj) {
        startXunfeiYuYinCallback(obj);
    }


    var endXunfeiYuYinCallback = function(obj) {};

    /**
     * 结束语音识别时
     * 需要回调（1、结束录音flag2、识别结果）
     */
    function endXunfeiYuYin(callback) {
		endXunfeiYuYinCallback = callback;
        if(window.iosdkqgqc) {
            window.webkit.messageHandlers.endXunfeiYuYin.postMessage(1);
        } else if(window.WebViewJ2CJavascriptBridge) {
            window.WebViewJ2CJavascriptBridge.callHandler(
                'Native.endXunfeiYuYin', {},

                function(responseData) {}
            );

        } else {
            throw new Error('J2C env init error');
        }
    }
    
    /**
     * Native中invoke了endXunfeiYuYin后回调JS的方法
     */
    function onendXunfeiYuYined(obj) {
        endXunfeiYuYinCallback(obj);
    }
    
    
    var cancelXunfeiYuYinCallback = function(obj) {};

    /**
     * 取消语音识别时
     * 需要回调（1、取消成功flag）
     */
    function cancelXunfeiYuYin(callback) {
		cancelXunfeiYuYinCallback = callback;
        if(window.iosdkqgqc) {
            window.webkit.messageHandlers.cancelXunfeiYuYin.postMessage(1);
        } else if(window.WebViewJ2CJavascriptBridge) {
            window.WebViewJ2CJavascriptBridge.callHandler(
                'Native.cancelXunfeiYuYin', {},

                function(responseData) {}
            );

        } else {
            throw new Error('J2C env init error');
        }
    }
    
    /**
     * Native中invoke了cancelXunfeiYuYin后回调JS的方法
     */
    function oncancelXunfeiYuYined(obj) {
        cancelXunfeiYuYinCallback(obj);
    }



    //---------------------deprecated --------------------------------------

	// 把函数注册到命名空间中
	window['J2C']['requestGetToken4NanNing'] = requestGetToken4Nanning;
	window['J2C']['onGetTokenSuccessed4NanNing'] = onGetTokenSuccessed4NanNing;

	window['J2C']['requestISLogin'] = requestISLogin;
	window['J2C']['requestISLoginSuccessed'] = requestISLoginSuccessed;
	window['J2C']['requestPensionCertification'] = requestPensionCertification;
	window['J2C']['requestPensionCertificationSuccessed'] = requestPensionCertificationSuccessed;
	window['J2C']['requestInjuryCertification'] = requestInjuryCertification;
	window['J2C']['requestInjuryCertificationSuccessed'] = requestInjuryCertificationSuccessed;
	window['J2C']['requestSurvival'] = requestSurvival;
	window['J2C']['onrequestSurvivalSuccessed'] = onrequestSurvivalSuccessed;

	window['J2C']['viewPdf'] = viewPdf;

	window['J2C']['scanFace'] = scanFace;
	window['J2C']['onScanFaceSuccessed'] = onScanFaceSuccessed;

	window['J2C']['startQRCode'] = startQRCode;
	window['J2C']['onstartQRCodeSuccessed'] = onstartQRCodeSuccessed;


	window['J2C']['startXunfeiYuYin'] = startXunfeiYuYin;
	window['J2C']['onstartXunfeiYuYined'] = onstartXunfeiYuYined;
	window['J2C']['endXunfeiYuYin'] = endXunfeiYuYin;
	window['J2C']['onendXunfeiYuYined'] = onendXunfeiYuYined;
	window['J2C']['cancelXunfeiYuYin'] = cancelXunfeiYuYin;
	window['J2C']['oncancelXunfeiYuYined'] = oncancelXunfeiYuYined;


})();