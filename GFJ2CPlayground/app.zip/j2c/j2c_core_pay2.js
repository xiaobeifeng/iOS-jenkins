/**
 * This is common js for intercept with Native Application
 * using jsbridge
 *
 * Version 1.1.2
 *
 *
 */
(function() {

	// 判断window对象中是否存在"J2C"，如果不存在，注册命名空间 'J2C' 到window对象上
	if(undefined == window['J2C']) {
		window['J2C'] = {}
	}

	// ---------- JS -> Native ---------------------

	/*************************UnionPay***********************/
	/**
	 * paymentTransactionNumber 返回后的回调
	 * @param {Object} statusObject
	 */
	paymentTransactionNumberCallback = function(statusObject) {};

	/**
	 * 传给原生调起支付银联SDK(社保交易流水号)
	 *
	 */
	function paymentTransactionNumber(obj, callback) {
		paymentTransactionNumberCallback = callback;
		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.paymentTransactionNumber.postMessage({
				'body': obj
			});
		} else if(window.WebViewJ2CJavascriptBridge) {
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.paymentTransactionNumber', obj,

				function(responseData) {}
			);

		} else {
			throw new Error('J2C env init error');
		}
	}

	/**
	 * 支付成功后回调JS的方法
	 */
	function paymentTransactionNumberSuccess(statusObject) {
		paymentTransactionNumberCallback(statusObject);
	}

	/***************************AliPay*************************/
	/**
	 * paymentTransactionNumber 返回后的回调
	 * @param {Object} statusObject
	 */
	initAliPayCallback = function(pay_result) {};

	/**
	 * 传给原生调起支付宝SDK
	 *
	 */
	function initAliPay(payInfo, callback) {
		initAliPayCallback = callback;
		if(window.iosdkqgqc) {
			window.webkit.messageHandlers.initAliPay.postMessage({
				'body': payInfo
			});
		} else if(window.WebViewJ2CJavascriptBridge) {
			window.WebViewJ2CJavascriptBridge.callHandler(
				'Native.initAliPay', payInfo,

				function(responseData) {}
			);

		} else {
			throw new Error('J2C env init error');
		}
	}

	/**
	 * 支付成功后回调JS的方法
	 */
	function aliPayResult(pay_result) {
		initAliPayCallback(pay_result);
	}

	//---------------------deprecated --------------------------------------
	window['J2C']['paymentTransactionNumber'] = paymentTransactionNumber;
	window['J2C']['paymentTransactionNumberSuccess'] = paymentTransactionNumberSuccess;
	window['J2C']['initAliPay'] = initAliPay;
	window['J2C']['aliPayResult'] = aliPayResult;
})();