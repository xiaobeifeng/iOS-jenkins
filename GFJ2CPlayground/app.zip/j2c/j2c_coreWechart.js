/**
 * This is common js for intercept with Native Application
 * using jsbridge
 *
 * Version 2.0.0
 *
 */

/*
 * 回退到指定page
 * obj：
 * toPageId:回退到的指定page的Id，不能没有，可以等于一个空串，表示回退到上一个，没有查询到pageId，则关闭页面
 */

function webBackToPageWechart(obj) {
	var ishas = false;
	if(localStorage.getItem("curPageList") == "" || localStorage.getItem("curPageList") == null) {
		var curPageList = [];
	} else {
		curPageList = JSON.parse(localStorage.getItem("curPageList"));
		for(var i = 0; i < curPageList.length; i++) {
			if(obj.toPageId == curPageList[0].pageId) {
				localStorage.removeItem("curPageList");
				location.href = curPageList[0].url;
				ishas = true;
				break;
			} else if((obj.toPageId == curPageList[i].pageId) && (obj.toPageId != curPageList[0].pageId)) {
				location.href = curPageList[i].url;
				ishas = true;
				break;
			}
			if(obj.toPageId == "" || obj.toPageId == null) {
				ishas = true;
				history.go(-1);
				break;
			}
		}
	}
	// 没有对应的pageId，直接关闭
	if(!ishas) {
		WeixinJSBridge.call('closeWindow');
	}
}
